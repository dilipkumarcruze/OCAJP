package spring;


@Component
public class GreetingService {
    public void greet() {
        System.out.println("Hello, world!");
    }
}


